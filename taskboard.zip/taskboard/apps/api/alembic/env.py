"""Alembic environment configuration for R02 migrations."""

from __future__ import annotations

import sys
from pathlib import Path
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# Ensure the api src tree is on the path so models can be imported.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from mahak_api.models.user import Base as UserBase
from mahak_api.models.social_identity import SocialIdentityLink  # noqa: F401 — registers table
from mahak_api.models.session import Session  # noqa: F401 — registers table

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Target metadata for autogenerate — includes ALL R02 models.
target_metadata = UserBase.metadata

# Override the sqlalchemy.url so migrations use the project's DATABASE_URL env var.
config.set_main_option("sqlalchemy.url", "")


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection, target_metadata=target_metadata,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
